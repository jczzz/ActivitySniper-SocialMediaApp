<html>
        <head>
                <title><?php echo $title; ?></title>
        </head>
        <body>


                <h1><?php echo $title; ?></h1>
